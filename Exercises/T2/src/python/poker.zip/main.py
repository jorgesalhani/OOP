"""
@author: Jorge Augusto Salgado Salhani - 8927418
"""

from utils.poker.poker import Poker

if __name__ == '__main__':
    poker = Poker()
    poker.jogarPoker()