package Exercises.T2.src.java;
import Exercises.T2.src.java.utils.*;

public class Bozo {

  public static void main(String args[]) throws java.io.IOException {
    BozoJogo bozoJogo = new BozoJogo();
    bozoJogo.jogar();
  }
}
